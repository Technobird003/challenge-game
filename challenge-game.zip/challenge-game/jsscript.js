const challenges = [
    "Perform 20 push-ups.",
    "Dance for 30 seconds.",
    "Sing a random song.",
    "Do a funny face.",
    "Say a tongue twister five times fast.",
    "Try to juggle three objects.",
    "Do your best impression of a celebrity.",
    "Tell a joke.",
    "Attempt a yoga pose.",
    "Create a silly dance routine.",
    "Speak in an accent for one minute.",
    "Do a 30-second plank.",
    "Draw a picture of a random object with your non-dominant hand.",
    "Balance on one foot for 30 seconds.",
    "Make up a short poem on the spot.",
    "Do 10 squats.",
    "Imitate an animal of your choice.",
    "Try to solve a simple riddle.",
    "Sing your favorite song in a high pitch.",
    "Create and perform a short skit.",
    "Tell a funny story from your childhood.",
    "Act out a scene from a movie.",
    "Do a quick workout routine.",
    "Try to remember and recite a random fact.",
    "Challenge someone else to a silly duel (like thumb wrestling).",
];

const prizeThreshold = 25;
let challengeCount = 0;

document.getElementById('buzzer').addEventListener('click', showChallenge);
document.addEventListener('keydown', (event) => {
    if (event.key === 'Enter') {
        showChallenge();
    }
});

function showChallenge() {
    challengeCount++;
    if (challengeCount <= prizeThreshold) {
        const randomChallenge = challenges[Math.floor(Math.random() * challenges.length)];
        document.getElementById('challenge').textContent = randomChallenge;
        document.getElementById('message').textContent = "";
    }
    if (challengeCount === prizeThreshold) {
        document.getElementById('challenge').textContent = "";
        document.getElementById('message').textContent = "Congratulations! You've completed 25 challenges and won a prize of 30CHF!";
    }
    if (challengeCount > prizeThreshold) {
        document.getElementById('challenge').textContent = "";
        document.getElementById('message').textContent = "Thank you for playing!";
    }
}
